 
        document.getElementById('produit1Link').addEventListener('click', function() {
            document.getElementById('histoireImage').style.display = 'none';
            document.getElementById('produit1').style.display = 'block';
            document.getElementById('produit2').style.display = 'none';
        });

       
        document.getElementById('produit2Link').addEventListener('click', function() {
            document.getElementById('histoireImage').style.display = 'none';
            document.getElementById('produit1').style.display = 'none';
            document.getElementById('produit2').style.display = 'block';
        });



    