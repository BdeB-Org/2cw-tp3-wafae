 document.getElementById('produit3Link').addEventListener('click', function() {
            document.getElementById('histoireImage').style.display = 'none';
            document.getElementById('produit3').style.display = 'block';
            document.getElementById('produit4').style.display = 'none';
        });

       
        document.getElementById('produit4Link').addEventListener('click', function() {
            document.getElementById('histoireImage').style.display = 'none';
            document.getElementById('produit3').style.display = 'none';
            document.getElementById('produit4').style.display = 'block';
        });

     