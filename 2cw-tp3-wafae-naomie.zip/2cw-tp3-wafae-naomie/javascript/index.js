document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('abonnement').addEventListener('click', function() {
        window.location.href = 'html/abonnement.html';
    });
});